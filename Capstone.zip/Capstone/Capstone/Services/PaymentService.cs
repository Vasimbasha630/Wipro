﻿namespace HotelBooking.Api.Services;

public class PaymentService
{
    public Task<(bool ok, string confirmation)> ChargeAsync(decimal amount, string method)
    {
        return Task.FromResult((true, $"PMT-{Guid.NewGuid():N}".Substring(0, 12)));
    }
}
