﻿using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Models;

public class Hotels
{
    public int Id { get; set; }
    [Required, MaxLength(120)] public string Name { get; set; } = string.Empty;
    [Required, MaxLength(120)] public string City { get; set; } = string.Empty;
    [MaxLength(300)] public string? Address { get; set; }
    public string? Description { get; set; }
    public double AvgRating { get; set; }
    public ICollection<Room> Rooms { get; set; } = new List<Room>();
}

public enum RoomType { Single, Double, Suite }

public class Room
{
    public int Id { get; set; }
    public int HotelId { get; set; }
    public Hotels? Hotel { get; set; }
    public RoomType Type { get; set; }
    public decimal PricePerNight { get; set; }
    public int TotalInventory { get; set; }
}
