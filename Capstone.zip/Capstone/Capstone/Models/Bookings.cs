﻿using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Models;

public enum BookingStatus { Pending, Confirmed, CheckedIn, CheckedOut, Cancelled }

public class   Bookings
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public Users? User { get; set; }
    public int RoomId { get; set; }
    public Room? Room { get; set; }
    public DateOnly CheckIn { get; set; }
    public DateOnly CheckOut { get; set; }
    public int Guests { get; set; }
    public decimal TotalAmount { get; set; }
    public BookingStatus Status { get; set; } = BookingStatus.Pending;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
