﻿using System.ComponentModel.DataAnnotations;

namespace HotelBooking.Api.Models;

public class Reviews
{
    public int Id { get; set; }
    public int HotelId { get; set; }
    public Hotels? Hotel { get; set; }
    public int UserId { get; set; }
    public Users? User { get; set; }
    [Range(1, 5)] public int Rating { get; set; }
    [MaxLength(500)] public string? Comment { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
