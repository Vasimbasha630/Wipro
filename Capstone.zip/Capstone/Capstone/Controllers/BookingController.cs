﻿//using HotelBooking.Api.Data;
//using HotelBooking.Api.Models;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using System.Security.Claims;

//[ApiController]
//[Route("api/bookings")]
//[Authorize]
//public class BookingController : ControllerBase
//{
//    private readonly AppDbContext _db;

//    public BookingController(AppDbContext db)
//    {
//        _db = db;
//    }

//    [HttpPost]
//    public async Task<IActionResult> CreateBooking(Bookings booking)
//    {
//        _db.Bookings.Add(booking);
//        await _db.SaveChangesAsync();
//        return Ok(booking);
//    }

//    [HttpGet("my")]
//    public async Task<IActionResult> MyBookings()
//    {
//        var email = User.FindFirstValue(ClaimTypes.Email);
//        var user = await _db.Users.SingleOrDefaultAsync(u => u.Email == email);
//        var bookings = await _db.Bookings.Where(b => b.UserId == user.Id).Include(b => b.Room).ToListAsync();
//        return Ok(bookings);
//    }
//}


using HotelBooking.Api.Data;
using HotelBooking.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace HotelBooking.Api.Controllers
{
    [ApiController]
    [Route("api/bookings")]
    [Authorize] // Only logged-in users can access
    public class BookingController : ControllerBase
    {
        private readonly AppDbContext _db;

        public BookingController(AppDbContext db)
        {
            _db = db;
        }

        // POST: api/bookings
        [HttpPost]
        public async Task<IActionResult> CreateBooking([FromBody] Bookings booking)
        {
            // Get the logged-in user's email from JWT token
            var email = User.FindFirstValue(ClaimTypes.Email);
            var user = await _db.Users.SingleOrDefaultAsync(u => u.Email == email);

            if (user == null)
                return Unauthorized("Invalid user token");

            // Assign user ID to the booking, prevent nested object insertion
            booking.UserId = user.Id;
            booking.User = null;

            // Validate room exists
            var room = await _db.Rooms.FindAsync(booking.RoomId);
            if (room == null)
                return BadRequest("Invalid RoomId");

            booking.Room = null; // Avoid nested insertion
            booking.Status = BookingStatus.Pending;
            booking.CreatedAt = DateTime.UtcNow;

            _db.Bookings.Add(booking);
            await _db.SaveChangesAsync();

            return Ok(booking);
        }

        // GET: api/bookings/my
        [HttpGet("my")]
        public async Task<IActionResult> MyBookings()
        {
            var email = User.FindFirstValue(ClaimTypes.Email);
            var user = await _db.Users.SingleOrDefaultAsync(u => u.Email == email);

            if (user == null)
                return Unauthorized("Invalid user token");

            var bookings = await _db.Bookings
                .Where(b => b.UserId == user.Id)
                .Include(b => b.Room)
                    .ThenInclude(r => r.Hotel)
                .ToListAsync();

            return Ok(bookings);
        }

        // GET: api/bookings/all (Admin only)
        [HttpGet("all")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllBookings()
        {
            var bookings = await _db.Bookings
                .Include(b => b.User)
                .Include(b => b.Room)
                    .ThenInclude(r => r.Hotel)
                .ToListAsync();

            return Ok(bookings);
        }
    }
}

