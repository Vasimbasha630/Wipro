﻿//using Capstone.DTOs;
//using HotelBooking.Api.Data;
//using HotelBooking.Api.Models;
//using HotelBooking.Api.Services;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;

//namespace HotelBooking.Api.Controllers;

//[ApiController]
//[Route("api/auth")]
//public class AuthController : ControllerBase
//{
//    private readonly AppDbContext _db;
//    private readonly JwtTokenService _jwt;

//    public AuthController(AppDbContext db, JwtTokenService jwt)
//    {
//        _db = db;
//        _jwt = jwt;
//    }

//    [HttpPost("register")]
//    public async Task<ActionResult<AuthResponse>> Register(RegisterRequest req)
//    {
//        if (await _db.Users.AnyAsync(u => u.Email == req.Email))
//            return BadRequest("Email already registered");

//        var user = new Users
//        {
//            Name = req.Name,
//            Email = req.Email,
//            PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.Password)
//        };

//        _db.Users.Add(user);
//        await _db.SaveChangesAsync();

//        var token = _jwt.CreateToken(user);
//        return new AuthResponse(token, user.Name, user.Email, user.Role.ToString());
//    }

//    [HttpPost("login")]
//    public async Task<ActionResult<AuthResponse>> Login(LoginRequest req)
//    {
//        var user = await _db.Users.SingleOrDefaultAsync(u => u.Email == req.Email);
//        if (user is null || !BCrypt.Net.BCrypt.Verify(req.Password, user.PasswordHash))
//            return Unauthorized();

//        var token = _jwt.CreateToken(user);
//        return new AuthResponse(token, user.Name, user.Email, user.Role.ToString());
//    }
//}



using HotelBooking.Api.Data;
using HotelBooking.Api.Models;
using HotelBooking.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Capstone.DTOs;

namespace HotelBooking.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly JwtTokenService _jwt;

    public AuthController(AppDbContext db, JwtTokenService jwt)
    {
        _db = db;
        _jwt = jwt;
    }

    [HttpPost("register")]
    public async Task<ActionResult<AuthResponse>> Register(RegisterRequest req)
    {
        if (await _db.Users.AnyAsync(u => u.Email == req.Email))
            return BadRequest("Email already registered");

        var user = new Users
        {
            Name = req.Name,
            Email = req.Email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.Password)
        };

        _db.Users.Add(user);
        await _db.SaveChangesAsync();

        var token = _jwt.CreateToken(user);
        return new AuthResponse(token, user.Name, user.Email, user.Role.ToString());
    }

    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login(LoginRequest req)
    {
        var user = await _db.Users.SingleOrDefaultAsync(u => u.Email == req.Email);
        if (user == null || !BCrypt.Net.BCrypt.Verify(req.Password, user.PasswordHash))
            return Unauthorized();

        var token = _jwt.CreateToken(user);
        return new AuthResponse(token, user.Name, user.Email, user.Role.ToString());
    }
}
