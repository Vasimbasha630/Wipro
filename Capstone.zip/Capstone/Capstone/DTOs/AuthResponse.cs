﻿namespace Capstone.DTOs
{
    public class AuthResponse
    {
        public string Token { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }

        public AuthResponse(string token, string name, string email, string role)
        {
            Token = token;
            Name = name;
            Email = email;
            Role = role;
        }
    }
}
