﻿using HotelBooking.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelBooking.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Users> Users => Set<Users>();
    public DbSet<Hotels> Hotels => Set<Hotels>();
    public DbSet<Room> Rooms => Set<Room>();
    public DbSet<Bookings> Bookings => Set<Bookings>();
    public DbSet<Reviews> Reviews => Set<Reviews>();
}
