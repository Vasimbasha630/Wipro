﻿using HotelBooking.Api.Data;
using HotelBooking.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelBooking.Api.Data;

public static class SeedData
{
    public static async Task InitAsync(AppDbContext db)
    {
        if (await db.Users.AnyAsync()) return;

        var admin = new Users { Name = "Admin", Email = "admin@demo.com", PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin@123"), Role = UserRole.Admin };
        var user = new Users { Name = "Alice", Email = "alice@demo.com", PasswordHash = BCrypt.Net.BCrypt.HashPassword("User@123"), Role = UserRole.Guest };
        db.Users.AddRange(admin, user);

        var h1 = new Hotels { Name = "Sunrise Inn", City = "Hyderabad", Address = "Hitech City", Description = "Business hotel" };
        var h2 = new Hotels { Name = "Coastal Breeze", City = "Vizag", Address = "Beach Rd", Description = "Sea view" };
        db.Hotels.AddRange(h1, h2);
        await db.SaveChangesAsync();

        db.Rooms.AddRange(
            new Room { HotelId = h1.Id, Type = RoomType.Single, PricePerNight = 2000, TotalInventory = 10 },
            new Room { HotelId = h1.Id, Type = RoomType.Double, PricePerNight = 3200, TotalInventory = 8 },
            new Room { HotelId = h2.Id, Type = RoomType.Single, PricePerNight = 1800, TotalInventory = 12 },
            new Room { HotelId = h2.Id, Type = RoomType.Suite, PricePerNight = 5200, TotalInventory = 4 }
        );
        await db.SaveChangesAsync();
    }
}
