﻿using System.ComponentModel.DataAnnotations;

namespace HotelReservationApi.DTOs
{
    public class UserRegisterDTO
    {
        [Required] public string Name { get; set; } = "";
        [Required][EmailAddress] public string Email { get; set; } = "";
        [Required] public string Password { get; set; } = "";
    }
}
