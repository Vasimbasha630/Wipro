﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HotelReservationApi.Models
{
    public class Room
    {
        public int Id { get; set; }
        [Required] public int HotelId { get; set; }
        [Required] public string RoomNumber { get; set; } = "";
        [Required] public string RoomType { get; set; } = "";
        [Required] public decimal Price { get; set; }
        [Required] public bool IsAvailable { get; set; } = true;

        public Hotel? Hotel { get; set; }
        public ICollection<Booking>? Bookings { get; set; }
    }
}
