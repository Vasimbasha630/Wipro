﻿using HotelReservationApi.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelReservationApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HotelController : ControllerBase
    {
        private readonly AppDbContext _context;

        public HotelController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetHotels([FromQuery] string? city)
        {
            var query = _context.Hotels.AsQueryable();
            if (!string.IsNullOrEmpty(city))
                query = query.Where(h => h.City.ToLower() == city.ToLower());

            var hotels = await query.Include(h => h.Rooms).ToListAsync();
            return Ok(hotels);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetHotel(int id)
        {
            var hotel = await _context.Hotels
                .Include(h => h.Rooms)
                .FirstOrDefaultAsync(h => h.Id == id);
            if (hotel == null) return NotFound();
            return Ok(hotel);
        }
    }
}
