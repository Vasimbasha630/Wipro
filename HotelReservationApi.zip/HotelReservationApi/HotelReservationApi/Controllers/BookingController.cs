﻿using HotelReservationApi.DTOs;
using HotelReservationApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HotelReservationApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BookingController : ControllerBase
    {
        private readonly BookingService _bookingService;

        public BookingController(BookingService bookingService)
        {
            _bookingService = bookingService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateBooking(BookingDTO dto)
        {
            var userId = int.Parse(User.FindFirstValue("id")!);
            var booking = await _bookingService.CreateBooking(userId, dto);
            if (booking == null) return BadRequest("Room not available for selected dates.");
            return Ok(booking);
        }
    }
}
