﻿using HotelReservationApi.Data;
using HotelReservationApi.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HotelReservationApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AdminController(AppDbContext context)
        {
            _context = context;
        }

        // Manage Hotels
        [HttpPost("hotels")]
        public async Task<IActionResult> AddHotel(Hotel hotel)
        {
            _context.Hotels.Add(hotel);
            await _context.SaveChangesAsync();
            return Ok(hotel);
        }

        [HttpPut("hotels/{id}")]
        public async Task<IActionResult> UpdateHotel(int id, Hotel hotel)
        {
            var h = await _context.Hotels.FindAsync(id);
            if (h == null) return NotFound();
            h.Name = hotel.Name;
            h.Address = hotel.Address;
            h.City = hotel.City;
            h.Description = hotel.Description;
            await _context.SaveChangesAsync();
            return Ok(h);
        }

        [HttpDelete("hotels/{id}")]
        public async Task<IActionResult> DeleteHotel(int id)
        {
            var h = await _context.Hotels.FindAsync(id);
            if (h == null) return NotFound();
            _context.Hotels.Remove(h);
            await _context.SaveChangesAsync();
            return Ok();
        }

        // Manage Rooms
        [HttpPost("rooms")]
        public async Task<IActionResult> AddRoom(Room room)
        {
            _context.Rooms.Add(room);
            await _context.SaveChangesAsync();
            return Ok(room);
        }

        [HttpPut("rooms/{id}")]
        public async Task<IActionResult> UpdateRoom(int id, Room room)
        {
            var r = await _context.Rooms.FindAsync(id);
            if (r == null) return NotFound();
            r.RoomNumber = room.RoomNumber;
            r.RoomType = room.RoomType;
            r.Price = room.Price;
            r.IsAvailable = room.IsAvailable;
            r.HotelId = room.HotelId;
            await _context.SaveChangesAsync();
            return Ok(r);
        }

        [HttpDelete("rooms/{id}")]
        public async Task<IActionResult> DeleteRoom(int id)
        {
            var r = await _context.Rooms.FindAsync(id);
            if (r == null) return NotFound();
            _context.Rooms.Remove(r);
            await _context.SaveChangesAsync();
            return Ok();
        }

        // Manage Bookings
        [HttpGet("bookings")]
        public async Task<IActionResult> GetAllBookings()
        {
            var bookings = await _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Room)
                .ToListAsync();
            return Ok(bookings);
        }

        [HttpPut("bookings/{id}/status")]
        public async Task<IActionResult> UpdateBookingStatus(int id, [FromQuery] string status)
        {
            var b = await _context.Bookings.FindAsync(id);
            if (b == null) return NotFound();
            b.Status = status;
            await _context.SaveChangesAsync();
            return Ok(b);
        }
    }
}
