﻿using HotelReservationApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HotelReservationApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PaymentController : ControllerBase
    {
        private readonly PaymentService _paymentService;

        public PaymentController(PaymentService paymentService)
        {
            _paymentService = paymentService;
        }

        [HttpPost("{bookingId}")]
        public async Task<IActionResult> Pay(int bookingId, [FromQuery] decimal amount)
        {
            var payment = await _paymentService.MakePayment(bookingId, amount);
            if (payment == null) return BadRequest("Payment failed or booking invalid.");
            return Ok(payment);
        }
    }
}
