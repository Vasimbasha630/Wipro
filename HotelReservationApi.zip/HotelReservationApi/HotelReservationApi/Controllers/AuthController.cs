﻿using HotelReservationApi.DTOs;
using HotelReservationApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace HotelReservationApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _auth;

        public AuthController(AuthService auth)
        {
            _auth = auth;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(UserRegisterDTO dto)
        {
            var user = await _auth.Register(dto);
            if (user == null) return BadRequest("Email already exists.");
            return Ok(user);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDTO dto)
        {
            var token = await _auth.Login(dto);
            if (token == null) return Unauthorized("Invalid credentials.");
            return Ok(new { token });
        }

    }
}
