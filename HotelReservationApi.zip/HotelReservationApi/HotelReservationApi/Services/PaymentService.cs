﻿using HotelReservationApi.Data;
using HotelReservationApi.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelReservationApi.Services
{
    public class PaymentService
    {
        private readonly AppDbContext _context;

        public PaymentService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Payment?> MakePayment(int bookingId, decimal amount)
        {
            var booking = await _context.Bookings.FindAsync(bookingId);
            if (booking == null || booking.Status != "Pending") return null;

            var payment = new Payment
            {
                BookingId = bookingId,
                Amount = amount,
                Status = "Completed"
            };

            booking.Status = "Confirmed";
            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();

            return payment;
        }
    }
}
