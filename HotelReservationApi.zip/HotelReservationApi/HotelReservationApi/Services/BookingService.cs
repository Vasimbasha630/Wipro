﻿using HotelReservationApi.Data;
using HotelReservationApi.DTOs;
using HotelReservationApi.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelReservationApi.Services
{
    public class BookingService
    {
        private readonly AppDbContext _context;

        public BookingService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<bool> IsRoomAvailable(int roomId, DateTime checkIn, DateTime checkOut)
        {
            return !await _context.Bookings
                .AnyAsync(b => b.RoomId == roomId && b.Status != "Cancelled" &&
                b.CheckIn < checkOut && b.CheckOut > checkIn);
        }

        public async Task<Booking?> CreateBooking(int userId, BookingDTO dto)
        {
            if (!await IsRoomAvailable(dto.RoomId, dto.CheckIn, dto.CheckOut))
                return null;

            var booking = new Booking
            {
                UserId = userId,
                RoomId = dto.RoomId,
                CheckIn = dto.CheckIn,
                CheckOut = dto.CheckOut,
                Status = "Pending"
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();
            return booking;
        }
    }
}
