﻿using HotelReservationApi.Data;
using HotelReservationApi.DTOs;
using HotelReservationApi.Helpers;
using HotelReservationApi.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelReservationApi.Services
{
    public class AuthService
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _config;

        public AuthService(AppDbContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        // Register normal users
        public async Task<User?> Register(UserRegisterDTO dto)
        {
            if (await _context.Users.AnyAsync(u => u.Email == dto.Email))
                return null;

            var user = new User
            {
                Name = dto.Name,
                Email = dto.Email,
                PasswordHash = PasswordHasher.Hash(dto.Password),
                Role = "User"
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }

        // Login user/admin
        public async Task<string?> Login(LoginDTO dto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == dto.Email);

            if (user == null)
                return null; // user not found

            // Verify password
            bool isPasswordValid = false;

            try
            {
                isPasswordValid = PasswordHasher.Verify(dto.Password, user.PasswordHash);
            }
            catch
            {
                // If old hash format or invalid, fail gracefully
                return null;
            }

            if (!isPasswordValid)
                return null; // invalid password

            // Generate JWT token
            var token = JwtHelper.GenerateToken(user,
                _config["Jwt:Key"], _config["Jwt:Issuer"], _config["Jwt:Audience"]);

            return token;
        }

        // Ensure admin exists (optional, call at startup)
        public async Task EnsureAdminExists()
        {
            var adminEmail = "admin@hotel.com";
            var admin = await _context.Users.FirstOrDefaultAsync(u => u.Email == adminEmail);
            if (admin == null)
            {
                var newAdmin = new User
                {
                    Name = "Admin",
                    Email = adminEmail,
                    PasswordHash = PasswordHasher.Hash("Admin123!"), // default admin password
                    Role = "Admin"
                };

                _context.Users.Add(newAdmin);
                await _context.SaveChangesAsync();
            }
        }
    }
}
