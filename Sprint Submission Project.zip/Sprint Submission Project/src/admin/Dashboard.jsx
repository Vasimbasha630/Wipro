export default function Dashboard(){
  return (
    <div className="card">
      <div className="card-body">
        <h2>Dashboard</h2>
        <p className="subtitle">Manage hotels, rooms, and keep track of bookings.</p>
      </div>
    </div>
  );
}
