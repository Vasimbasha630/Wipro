export default function Spinner(){
  return <div style={{padding:"2rem", textAlign:"center"}}>Loading…</div>;
}
