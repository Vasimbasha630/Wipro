﻿namespace Aug_25_Car_Rental_Core.Models
{
    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}

