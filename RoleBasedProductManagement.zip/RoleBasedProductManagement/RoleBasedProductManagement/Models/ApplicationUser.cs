﻿using Microsoft.AspNetCore.Identity;

namespace RoleBasedProductManagement.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}
